/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#include <string>
#include <map>

#include <sourcing2010.hxx>


#include <teamcenter/soa/internal/server/SdmParser.hxx>
#include <teamcenter/soa/internal/server/SdmStream.hxx>

using namespace VF4::Soa::Custom::_2020_10;

const std::string Sourcing::XSD_NAMESPACE ="http://vf4.com/Schemas/Custom/2020-10/Sourcing";







Sourcing::Sourcing()
{
}

Sourcing::~Sourcing()
{
}

